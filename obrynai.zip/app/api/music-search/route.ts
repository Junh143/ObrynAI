import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type")

    if (contentType?.includes("multipart/form-data")) {
      const formData = await request.formData()
      const file = formData.get("file") as File

      if (!file) {
        return Response.json({ result: "음악 파일을 선택해주세요." })
      }

      // 오디오 파일을 Base64로 변환
      const buffer = await file.arrayBuffer()
      const base64 = Buffer.from(buffer).toString("base64")

      const prompt = `사용자가 업로드한 음악 파일을 분석했습니다. 파일명: ${file.name}
      이 음악이 어떤 곡인지 추측하고 정보를 한국어로 제공해주세요.
      
      다음 정보를 포함하세요:
      1. 예상되는 곡 제목
      2. 아티스트
      3. 장르
      4. 추정 릴리스 연도
      5. 음악의 특징 (비트, 보컬 스타일 등)
      6. 유사한 곡 추천
      
      파일명이나 메타데이터에서 정보를 추론해주세요.`

      const { text } = await generateText({
        model: groq("llama-3.3-70b-versatile"),
        prompt: prompt,
      })

      return Response.json({ result: text })
    }

    const { query } = await request.json()

    if (!query) {
      return Response.json({ result: "검색어를 입력해주세요." })
    }

    const prompt = `사용자가 "${query}"라는 음악을 검색했습니다. 이 노래 또는 아티스트에 대한 정보를 한국어로 제공해주세요. 
다음 정보를 포함하세요:
1. 곡 제목 (또는 아티스트명)
2. 아티스트 정보
3. 장르
4. 릴리스 연도
5. 주요 특징 또는 가사 하이라이트
6. 유사한 곡 추천

존재하지 않는 노래인 경우 비슷한 노래를 추천해주세요.`

    const { text } = await generateText({
      model: groq("llama-3.3-70b-versatile"),
      prompt: prompt,
    })

    return Response.json({ result: text })
  } catch (error) {
    console.error("Music search error:", error)
    return Response.json({ result: "음악 검색 중 오류가 발생했습니다." }, { status: 500 })
  }
}
