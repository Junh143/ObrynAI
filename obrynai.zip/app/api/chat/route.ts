function detectLanguage(text: string): string {
  const trimmedText = text.trim()

  const koreanPattern = /[\uAC00-\uD7AF]/g
  const englishPattern = /[a-zA-Z]/g
  const chinesePattern = /[\u4E00-\u9FFF]/g
  const japanesePattern = /[\u3040-\u309F\u30A0-\u30FF]/g

  const koreanMatch = trimmedText.match(koreanPattern) || []
  const englishMatch = trimmedText.match(englishPattern) || []
  const chineseMatch = trimmedText.match(chinesePattern) || []
  const japaneseMatch = trimmedText.match(japanesePattern) || []

  // 전체 언어 문자 개수
  const totalLangChars = koreanMatch.length + englishMatch.length + chineseMatch.length + japaneseMatch.length

  // 만약 언어 문자가 없으면 영어로 기본값 설정
  if (totalLangChars === 0) return "English"

  // 언어별 비율 계산
  const koreanRatio = koreanMatch.length / totalLangChars
  const englishRatio = englishMatch.length / totalLangChars
  const chineseRatio = chineseMatch.length / totalLangChars
  const japaneseRatio = japaneseMatch.length / totalLangChars

  // 가장 높은 비율의 언어 반환
  if (koreanRatio > englishRatio && koreanRatio > chineseRatio && koreanRatio > japaneseRatio) return "Korean"
  if (chineseRatio > englishRatio && chineseRatio > japaneseRatio) return "Chinese"
  if (japaneseRatio > englishRatio) return "Japanese"

  return "English"
}

export async function POST(request: Request) {
  try {
    const {
      message,
      isLearning,
      language,
      customSystemPrompt,
      responseLength,
      conversationHistory = [],
    } = await request.json()

    const apiKey = process.env.GROQ_API_KEY
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "GROQ_API_KEY is not set" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      })
    }

    let systemPrompt =
      "You are a helpful AI assistant. Speak in a casual, friendly tone. Be direct and creative in all responses. Maintain context from previous messages."

    let maxTokens = 1024
    if (responseLength === "short") maxTokens = 512
    else if (responseLength === "medium") maxTokens = 1024
    else if (responseLength === "long") maxTokens = 2048

    if (customSystemPrompt) {
      systemPrompt = customSystemPrompt
    } else if (isLearning && language) {
      const languagePrompts: Record<string, string> = {
        english:
          "You are an English language teacher. Help the user learn English with clear explanations, examples, and corrections.",
        korean:
          "You are a Korean language teacher. Help the user learn Korean with clear explanations, examples, and corrections.",
        chinese:
          "You are a Mandarin Chinese teacher. Help the user learn Chinese with clear explanations, examples, and corrections.",
        spanish:
          "You are a Spanish language teacher. Help the user learn Spanish with clear explanations, examples, and corrections.",
        french:
          "You are a French language teacher. Help the user learn French with clear explanations, examples, and corrections.",
        japanese:
          "You are a Japanese language teacher. Help the user learn Japanese with clear explanations, examples, and corrections.",
        german:
          "You are a German language teacher. Help the user learn German with clear explanations, examples, and corrections.",
      }

      systemPrompt = languagePrompts[language] || systemPrompt
    } else if (language === "auto") {
      const detectedLanguage = detectLanguage(message)
      console.log(`[v0] Message: "${message}" | Detected as: ${detectedLanguage}`)

      if (detectedLanguage === "Korean") {
        systemPrompt = `당신은 Obryn AI라는 친근한 AI 어시스턴트입니다. 사용자가 한국어로 말하고 있습니다.
        
        반드시 다음 규칙을 따르세요:
        1. 항상 한국어로만 답변하세요
        2. 절대로 영어를 섞지 마세요
        3. 절대로 다른 언어를 섞지 마세요
        4. 한국어만 사용하세요
        
        사용자와의 대화 맥락을 유지하고, 친근하고 창의적으로 답변하세요.`
      } else if (detectedLanguage === "Chinese") {
        systemPrompt = `您是一个名叫Obryn AI的友好AI助手。用户正在使用中文与您交流。
        
        必须遵循以下规则：
        1. 始终只用中文回复
        2. 不要混入英文
        3. 不要混入其他语言
        4. 仅使用中文
        
        保持与用户的对话背景，友好而富有创意地回复。`
      } else if (detectedLanguage === "Japanese") {
        systemPrompt = `あなたはObryn AIという親しみやすいAIアシスタントです。ユーザーが日本語で話しています。
        
        必ず以下のルールに従ってください：
        1. 常に日本語だけで返信してください
        2. 絶対に英語を混ぜないでください
        3. 絶対に他の言語を混ぜないでください
        4. 日本語だけを使用してください
        
        ユーザーとの会話コンテキストを維持し、親しみやすく創造的に返信してください。`
      } else {
        systemPrompt = `You are a helpful AI assistant named Obryn AI. The user is speaking English.
        
        CRITICAL RULES - You MUST follow these:
        1. ALWAYS respond ONLY in English
        2. NEVER mix in Korean or any other languages
        3. NEVER switch languages
        4. Use ONLY English
        
        Be casual, friendly, and creative. Maintain conversation context.`
      }
    }

    const contextPrompt = `Remember the conversation history with the user and maintain a consistent personality and tone throughout this conversation.`

    const messages = [
      { role: "system" as const, content: systemPrompt + "\n\n" + contextPrompt },
      ...conversationHistory,
      { role: "user" as const, content: message },
    ]

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: messages,
        max_tokens: maxTokens,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      const errorData = await response.text()
      console.error("[v0] Groq API Error:", errorData)
      return new Response(JSON.stringify({ error: "Failed to get response from Groq API" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      })
    }

    const data = await response.json()
    const responseText = data.choices?.[0]?.message?.content || "No response generated"

    return new Response(JSON.stringify({ response: responseText }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error("[v0] Chat API Error:", error)
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
